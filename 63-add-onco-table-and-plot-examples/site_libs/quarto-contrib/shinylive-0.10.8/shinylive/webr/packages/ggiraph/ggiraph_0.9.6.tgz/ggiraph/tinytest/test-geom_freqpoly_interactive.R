library(tinytest)
library(ggiraph)
library(ggplot2)
source("setup.R")

# geom_freqpoly_interactive ----
{
  eval(test_geom_layer, envir = list(name = "geom_freqpoly_interactive"))
}
